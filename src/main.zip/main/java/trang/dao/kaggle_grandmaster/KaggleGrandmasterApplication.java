package trang.dao.kaggle_grandmaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KaggleGrandmasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(KaggleGrandmasterApplication.class, args);
	}

}
