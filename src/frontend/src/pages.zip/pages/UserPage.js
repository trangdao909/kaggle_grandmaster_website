import {useEffect, useState} from 'react';
import { Link, useParams } from 'react-router-dom';
import { MatchDetailCard } from "../components/MatchDetailCard"
import { YearSelector } from '../components/YearSelector';
import "./UserPage.scss";
import kaggleLogo from '../assets/kaggle-logo.png';
import twitterLogo from '../assets/twitter-logo.jpg';
import header from '../assets/header.jpg';




export const UserPage = () =>{
    const [user, setUser] = useState({});
    //const {userId: id} = useParams();
    
    useEffect(() =>{
        const fetchUser = async () =>{
            const response = await fetch(`${process.env.REACT_APP_API_ROOT_URL}/user/37166`);
            const data = await response.json();
            setUser(data);
            console.log(data);

        }
        fetchUser();
    }, [])
    return (
        <div className="UserPage">           
            <div>
                <img src={header} alt="header" className="header" />
                <h1 className="user-name">{user.displayName}</h1>
                <h2 className="title">{user.tier}</h2>
                <h2 className="rank">{user.currentRanking}</h2>               
            </div> 
            <div>
                <img src={kaggleLogo}  alt="kaggle-logo" className="kaggle-logo" />
                <Link to="">Url Link</Link>
                <img src={twitterLogo} alt="twitter-logo" className="twitter-logo" />
            </div>  
           
            <div>
                <h1>{user.userJoinDate}</h1>
                <h1>{user.points}</h1>
                
            </div>
            <div>Pie chart</div>
            <div>Footer</div>
                
        </div>
    );
}

